﻿<footer>
        <div class="row" id="stfooter">
          <div class="col-lg-6  col-md-6 col-sm-6">
          <ul>
              <li><a href="http://support.webhosting.dk/ENG" target="_blank">Support section</a></li>
              <li><a href="http://www.webhosting.dk/ENG/createaccount.php" target="_blank">Create account</a></li>
              <li><a href="http://www.webhosting.dk/ENG/createoffernew.php" target="_blank">View pricelist</a></li>
              <li><a href="http://www.webhosting.dk/ENG/createoffernew.php" target="_blank">Create order</a></li>
              <li><a href="http://www.webhosting.dk/ENG/accountsend.php" target="_blank">Forgot password ?</a></li>
              <li><a href="http://www.webhosting.dk/ENG/sendemail.php" target="_blank">Contact us</a></li>
         </ul>
         </div>
         <div class="col-lg-6  col-md-6 col-sm-6">
           <p> Social networking</p>
           <a href="http://www.facebook.com/webhosting.dk" target="_blank"><img src="images/fb.png" alt=""></a>
           <a href="https://twitter.com/webhostingdk" target="_blank"><img src="images/twitter.png" alt=""></a>
         </div>
       </div>
       <div class="row">
         <div class="col-lg-12">
         <p>WebHosting A/S, CVR 25674138, © 1996 - <?php echo date("Y");?></p>
         <p>© VN media</p>
        </div>
      </div>
</footer>